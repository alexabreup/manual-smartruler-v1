
import __ASTRO_IMAGE_IMPORT_1K5Sm3 from "../../assets/smartruler01.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx";
export default new Map([["../../assets/smartruler01.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx", __ASTRO_IMAGE_IMPORT_1K5Sm3]]);
		